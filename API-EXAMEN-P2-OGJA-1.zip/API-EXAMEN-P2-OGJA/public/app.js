// Obtener Lista de Estudiantes
const obtenerListaButton = document.querySelector('#obtenerListaButton');
const listaEstudiantes = document.querySelector('#listaEstudiantes');

obtenerListaButton.addEventListener('click', function() 
{
    fetch('http://localhost:3000/api/students')
        .then(response => response.json())
        .then(data => 
        {
            listaEstudiantes.innerHTML = ''; // Limpia la lista antes de agregar nuevos elementos
            data.forEach(student => {
                const listItem = document.createElement('li');
                listItem.textContent = `ID: ${student.id}, Nombre: ${student.name}`;
                listaEstudiantes.appendChild(listItem);
            });
        })
        .catch(error => console.error('Error al obtener estudiantes:', error));
});

// Eliminar un Estudiante
const eliminarEstudianteButton = document.querySelector('#eliminarEstudianteButton');
const eliminarEstudianteId = document.querySelector('#eliminarEstudianteId');

eliminarEstudianteButton.addEventListener('click', function() 
{
    const studentId = eliminarEstudianteId.value;

    fetch(`http://localhost:3000/api/students/${studentId}`, 
    {
        method: 'DELETE'
    })
    .then(response => {
        if (response.status === 200) 
        {
            // Mostrar mensaje de éxito: 'Estudiante eliminado'
            alert('Estudiante eliminado');
        } else if (response.status === 404) 
        {
            // Mostrar mensaje de error: 'Estudiante no encontrado'
            alert('Estudiante no encontrado');
        } else 
        {
            // Mostrar mensaje de error general
            alert('Error al eliminar estudiante');
        }
    })
    .catch(error => console.error('Error al eliminar estudiante:', error));
});

// Crear un Nuevo Estudiante
const crearEstudianteButton = document.querySelector('#crearEstudianteButton');
const nombreEstudiante = document.querySelector('#nombreEstudiante');
const apellidoEstudiante = document.querySelector('#apellidoEstudiante');
const gradoEstudiante = document.querySelector('#gradoEstudiante');

crearEstudianteButton.addEventListener('click', function() 
{
    // Obtener los valores de los campos
    const nombre = nombreEstudiante.value;
    const apellido = apellidoEstudiante.value;
    const grado = gradoEstudiante.value;

    // Verificar que todos los campos estén completos
    if (nombre && apellido && grado) 
    {
        const newStudentData = 
        {
            name: nombre,
            apellido: apellido,
            grado: grado
        };

        fetch('http://localhost:3000/api/students', 
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newStudentData)
        })
        .then(response => 
        {
            if (response.status === 201) 
            {
                // Mostrar mensaje de éxito: 'Estudiante creado correctamente'
                alert('Estudiante creado correctamente');
                nombreEstudiante.value = ''; // Limpiar los campos
                apellidoEstudiante.value = '';
                gradoEstudiante.value = '';
            } else 
            {
                // Mostrar mensaje de error general
                alert('Error al crear estudiante');
            }
        })
        .catch(error => console.error('Error al crear estudiante:', error));
    } else 
    {
        // Mostrar mensaje de error: 'Por favor, complete todos los campos'
        alert('Por favor, complete todos los campos');
    }
});

// Actualizar un Estudiante Existente
const actualizarEstudianteButton = document.querySelector('#actualizarEstudianteButton');
const actualizarEstudianteId = document.querySelector('#actualizarEstudianteId');
const actualizarEstudianteNombre = document.querySelector('#actualizarEstudianteNombre');
const actualizarEstudianteApellido = document.querySelector('#actualizarEstudianteApellido');

actualizarEstudianteButton.addEventListener('click', function() 
{
    const studentId = actualizarEstudianteId.value;
    const updatedName = actualizarEstudianteNombre.value;

    // Verificar que el ID y el nombre se hayan completado
    if (studentId && updatedName) 
    {
        const updatedStudentData = 
        {
            name: updatedName
        };

        fetch(`http://localhost:3000/api/students/${studentId}`, 
        {
            method: 'PUT',
            headers: 
            {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedStudentData)
        })
        .then(response => 
            {
            if (response.status === 200) 
            {
                // Mostrar mensaje de éxito: 'Estudiante actualizado'
                alert('Estudiante actualizado');
            } else if (response.status === 404) 
            {
                // Mostrar mensaje de error: 'Estudiante no encontrado'
                alert('Estudiante no encontrado');
            } else 
            {
                // Mostrar mensaje de error general
                alert('Error al actualizar estudiante');
            }
        })
        .catch(error => console.error('Error al actualizar estudiante:', error));
    } else 
    {
        // Mostrar mensaje de error: 'Por favor, complete el ID y el nombre'
        alert('Por favor, complete el ID y el nombre');
    }
});
