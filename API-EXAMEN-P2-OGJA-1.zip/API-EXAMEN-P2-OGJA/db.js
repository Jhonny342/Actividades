const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('api', 'Jonathan', '1234', 
{
  host: 'localhost',
  dialect: 'mysql',
});

module.exports = sequelize;
