// apiRequests.js
const API_BASE_URL = 'http://localhost:3000/api'; 

const apiRequests = 
{
  getStudents: () => 
  {
    return fetch(`${API_BASE_URL}/students`)
      .then(response => response.json());
  },

  getStudentGrades: (studentId) => 
  {
    return fetch(`${API_BASE_URL}/students/${studentId}/grades`)
      .then(response => response.json());
  },

  createStudent: (newStudent) => 
  {
    return fetch(`${API_BASE_URL}/students`, 
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newStudent)
    })
    .then(response => response.json());
  },

  updateStudent: (studentId, updatedStudent) => 
  {
    return fetch(`${API_BASE_URL}/students/${studentId}`, 
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(updatedStudent)
    })
    .then(response => response.json());
  },

  deleteStudent: (studentId) => 
  {
    return fetch(`${API_BASE_URL}/students/${studentId}`, 
    {
      method: 'DELETE'
    })
    .then(response => response.ok);
  }
};

module.exports = apiRequests; 