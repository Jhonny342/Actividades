// main.js
//Pruebas
const apiRequests = require('./Ci.js');

// Obtener la lista de estudiantes
apiRequests.getStudents()
  .then(students => 
  {
    console.log('Lista de estudiantes:', students);
  
    if (students.length > 0) 
    {
      const studentId = 2; 
        console.log(studentId);
      
      apiRequests.getStudentGrades(studentId)
        .then(grades => 
        {
          console.log('Calificaciones del estudiante', studentId, ':', grades);
        })
        .catch(error => 
        {
          console.error('Error al obtener las calificaciones del estudiante:', error);
        });
    }
  })
  .catch(error => 
  {
    console.error('Error al obtener la lista de estudiantes:', error);
  });

//Crear un nuevo estudiante
const newStudent = { name: 'Nuevo Estudiante', grades: [] };

apiRequests.createStudent(newStudent)
  .then(createdStudent => 
  {
    console.log('Estudiante creado:', createdStudent);
  })
    .catch(error => 
      {
        console.error('Error al eliminar el estudiante:', error);
      });
    
    //actualizar el estudiante
    const studentId = 2;
    const updatedStudent = { name: 'produ Actualizado', grades: [] };

    // Actualizar el estudiante
    apiRequests.updateStudent(studentId, updatedStudent)
      .then(updated => 
      {
        console.log('Estudiante actualizado:', updated);
      })
      .catch(error => 
        {
        console.error('Error al actualizar el estudiante:', error);
    apiRequests.deleteStudent(1)
      .then(deleted => 
        {
        if (deleted) 
        {
          console.log('Estudiante eliminado con éxito');
        } else 
        {
          console.error('Error al eliminar el estudiante');
        }
      })
      .catch(error => 
      {
        console.error('Error al eliminar el estudiante:', error);
      });
    });
   